# TreinaWeb: ["Workshop Multi-stack"](https://www.treinaweb.com.br/painel/multi-stack)

## Projeto e-diaristas (React + Next.js)

#### Lista de branches

|                                                                                              | Branch | Descrição |
| -------------------------------------------------------------------------------------------- | ------ | --------- |
| [Download](https://github.com/treinaweb/treinaweb-workshop-multistack-react/archive/v01.zip) | v01    | Versão 01 |
| [Download](https://github.com/treinaweb/treinaweb-workshop-multistack-react/archive/v02.zip) | v02    | Versão 02 |
